# Минимальные правила для сохранения классов
-keep class com.rocket.killer.** { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-dontwarn android.support.**
-dontwarn androidx.**